const K='nks_pos_v1'; let db=JSON.parse(localStorage.getItem(K)||'{"pin":"","sales":[],"products":[],"payments":[],"customers":{}}'); let cart=[];
function persist(){localStorage.setItem(K,JSON.stringify(db));}
function login(){let p=document.getElementById('pin').value;if(!p){return} if(!db.pin){db.pin=p;persist();openApp()}else if(db.pin===p){openApp()}else document.getElementById('msg').textContent='Wrong PIN';}
function openApp(){document.getElementById('login').classList.add('hidden');document.getElementById('app').classList.remove('hidden');refresh();}
function show(id){document.querySelectorAll('.page').forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden');refresh();}
function money(n){return '₹'+Number(n||0).toFixed(2)}
function addItem(){let n=pname.value.trim(),q=+qty.value||0,r=+rate.value||0;if(!n||q<=0||r<0)return;cart.push({n,q,r,a:q*r});renderCart()}
function renderCart(){cart.innerHTML='';let t=0;cart.forEach(x=>{t+=x.a;document.getElementById('cart').innerHTML+=`<tr><td>${x.n}</td><td>${x.q}</td><td>${money(x.r)}</td><td>${money(x.a)}</td></tr>`});document.getElementById('grand').textContent=money(t)}
function saveBill(){if(!cart.length)return alert('Add item');let total=cart.reduce((a,x)=>a+x.a,0),pd=+document.getElementById('paid').value||0,c=document.getElementById('customer').value.trim()||'Cash Customer';let bill={id:Date.now(),date:new Date().toISOString(),customer:c,items:cart,total,paid:pd,due:Math.max(0,total-pd)};db.sales.push(bill);db.customers[c]=(db.customers[c]||0)+bill.due;persist();cart=[];renderCart();alert('Bill saved: '+bill.id);refresh()}
function addProduct(){let n=newprod.value.trim(),s=+stock.value||0,r=+saleprice.value||0;if(!n)return;db.products.push({id:Date.now(),name:n,stock:s,price:r});persist();refresh();newprod.value='';stock.value='';saleprice.value=''}
function refresh(){let sales=db.sales,total=sales.reduce((a,x)=>a+x.total,0),paid=sales.reduce((a,x)=>a+x.paid,0),due=sales.reduce((a,x)=>a+x.due,0);document.getElementById('dsales').textContent=money(total);document.getElementById('dpaid').textContent=money(paid);document.getElementById('ddue').textContent=money(due);document.getElementById('dcust').textContent=Object.keys(db.customers).length;
document.getElementById('dailyList').innerHTML=sales.slice().reverse().map(x=>`<div class="cards"><div>Bill ${x.id}<br>${x.customer}<br>${money(x.total)} | Paid ${money(x.paid)} | Due ${money(x.due)}</div></div>`).join('');
document.getElementById('customerList').innerHTML=Object.entries(db.customers).map(([n,d])=>`<div class="cards"><div><b>${n}</b><br>Due: ${money(d)}</div></div>`).join('');
document.getElementById('productList').innerHTML=db.products.map(p=>`<div class="cards"><div>${p.name}<br>Stock: ${p.stock}<br>Sale: ${money(p.price)}</div></div>`).join('');
document.getElementById('paymentList').innerHTML=sales.map(x=>`<div class="cards"><div>${x.customer}: ${money(x.paid)} paid</div></div>`).join('');
}
function backup(){let blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='NKS_POS_Backup.json';a.click()}
function exportCSV(){let rows=[['Bill','Date','Customer','Total','Paid','Due']];db.sales.forEach(x=>rows.push([x.id,x.date,x.customer,x.total,x.paid,x.due]));let csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='NKS_Sales.csv';a.click()}
setInterval(()=>document.getElementById('clock').textContent=new Date().toLocaleString(),1000); renderCart();
