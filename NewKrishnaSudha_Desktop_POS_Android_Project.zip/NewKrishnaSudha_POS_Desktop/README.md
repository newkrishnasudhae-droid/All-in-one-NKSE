# New Krishna Sudha Enterprise — Desktop POS Android Project

This is an Android WebView project designed to build an APK on Android/PC.

Included:
- Desktop-style interface
- First-run Security PIN + login
- POS multi-item billing
- Paid/Due calculation
- Customer due summary
- Product/stock entry
- Daily sales
- Payments view
- CSV export
- JSON backup
- Print/PDF via Android/browser print dialog
- Responsive mobile + landscape desktop-like layout

## Build
Open this project in Android Studio, sync Gradle, then Build > Build APK(s).

The generated APK will be under:
app/build/outputs/apk/debug/app-debug.apk

Note: this ZIP is the complete source project; an APK binary is not embedded.
