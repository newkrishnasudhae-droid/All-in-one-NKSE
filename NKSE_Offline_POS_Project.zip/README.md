# New Krishna Sudha Enterprise — Offline POS APK Project

Version 1.0
- 100% offline WebView app
- No login server, cloud sync, API or internet dependency
- Dashboard, Sales/Invoice, Purchase, Customers, Items/Stock, Reports, Backup JSON, Print
- LocalStorage database on the Android device
- Designed for hardware/building-material shop workflow

Build:
1. Open this project in Android Studio.
2. Allow Gradle to sync (first build may need internet to download Android Gradle Plugin).
3. Build > Generate App Bundle / APK > Generate APK.
4. Install the resulting APK.

Important: The APP itself works offline after installation. Android Studio's first build may require internet for Gradle dependencies.
