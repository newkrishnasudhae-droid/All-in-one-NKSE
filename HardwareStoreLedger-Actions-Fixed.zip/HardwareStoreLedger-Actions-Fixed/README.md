# HardwareStoreLedger Actions Fixed

This package fixes the GitHub Actions failure shown by the workflow that expected `settings.gradle`.

The supplied project archive contains an already-built `app-debug.apk`, not a complete Android source project. Therefore this workflow packages and uploads that APK instead of running Gradle.

For a NEW APK build from source, the repository must contain the complete Android project, including `settings.gradle`, root `build.gradle`/`build.gradle.kts`, `gradle/`, `gradlew`, and `app/src/`.
