# New Krishna Sudha Enterprise - Offline POS

Android offline POS / hardware-store ledger project.

## Build with GitHub Actions
1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Run **Build Android APK**.
4. Download the artifact named **New-Krishna-Sudha-Enterprise-APK-v1.1**.

## Important
- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- No Kotlin runtime dependencies are used.
- The app uses Android WebView and localStorage for offline data.
