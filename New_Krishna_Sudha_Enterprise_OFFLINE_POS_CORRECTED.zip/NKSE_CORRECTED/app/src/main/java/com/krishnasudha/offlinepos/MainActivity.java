package com.krishnasudha.offlinepos;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Context;
import android.content.Intent;
import android.print.PrintAttributes;
import android.print.PrintManager;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(this), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public static class AndroidBridge {
        private final Context context;

        AndroidBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void shareText(String text) {
            try {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(Intent.createChooser(intent, "Share backup"));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void print(String html) {
            try {
                final WebView printView = new WebView(context);
                WebSettings ps = printView.getSettings();
                ps.setJavaScriptEnabled(false);
                printView.setWebViewClient(new WebViewClient());
                printView.loadDataWithBaseURL(null, html == null ? "" : html,
                        "text/html", "UTF-8", null);

                PrintManager manager = (PrintManager) context.getSystemService(Context.PRINT_SERVICE);
                if (manager != null) {
                    manager.print(
                            "New Krishna Sudha Invoice",
                            printView.createPrintDocumentAdapter("Invoice"),
                            new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .build()
                    );
                }
            } catch (Exception ignored) {
            }
        }
    }
}
