# HardwareStoreLedger GitHub Ready

This package is for packaging the already-built APK as a GitHub Actions artifact.

IMPORTANT: Upload the CONTENTS of this ZIP to the repository root, not the ZIP file itself.

The workflow does NOT require settings.gradle because this package contains an already-built APK.
For compiling a NEW APK from source, a complete Android source project is required.
