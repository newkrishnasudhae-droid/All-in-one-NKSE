package com.krishnasudha.offlinepos;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.content.Context;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(this), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
    public class AndroidBridge {
        Context c;
        AndroidBridge(Context c){this.c=c;}
        @JavascriptInterface public void print(String html){
            final WebView pv = new WebView(c);
            pv.getSettings().setJavaScriptEnabled(true);
            pv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            PrintManager pm=(PrintManager)c.getSystemService(Context.PRINT_SERVICE);
            pm.print("New Krishna Sudha Invoice", pv.createPrintDocumentAdapter("Invoice"),
                    new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
        }
        @JavascriptInterface public void shareText(String text){
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text);
            c.startActivity(Intent.createChooser(i,"Share backup"));
        }
    }
}
