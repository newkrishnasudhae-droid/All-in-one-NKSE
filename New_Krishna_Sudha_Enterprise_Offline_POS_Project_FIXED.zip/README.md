# New Krishna Sudha Enterprise - Offline POS

Android offline POS project.

## Build requirements
- JDK 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Android SDK 35

The project intentionally excludes old Kotlin JDK7/JDK8 stdlib modules to prevent
duplicate-class errors caused by mixed Kotlin stdlib versions.

## GitHub Actions
The included `.github/workflows/build.yml` pins Gradle to 8.9 and Java to 17.
Run **Actions -> Build Android APK -> Run workflow**. The generated debug APK
is uploaded as an artifact named `New-Krishna-Sudha-Enterprise-APK`.
