# New Krishna Sudha Enterprise — Offline POS
Independent Android WebView POS project. All business data is stored locally in the browser/WebView local database layer.

## Features
- PIN login/change PIN
- Dashboard
- POS billing with multiple items
- Customers, previous due, payments and statements
- Products, brands, categories and stock
- Daily price history and min/max selling price
- Sales returns
- Cash/UPI/partial payments
- Invoice printing and PDF via Android print/share UI
- Reports
- JSON/CSV backup and restore
- Fully offline UI (no remote API required)

## Build
Open this folder in Android Studio and let Gradle sync. Then Build > Generate App Bundle(s) / APK(s) > Generate APK(s).
Minimum SDK: 23. Target SDK: 35.
