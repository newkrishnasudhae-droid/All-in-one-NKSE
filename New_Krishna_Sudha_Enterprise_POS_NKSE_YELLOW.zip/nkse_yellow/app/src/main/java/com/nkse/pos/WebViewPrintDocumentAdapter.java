package com.nkse.pos;

import android.app.Activity;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebViewPrintDocumentAdapter extends PrintDocumentAdapter {
    private final Activity activity;
    private final String html;
    private final String invoice;
    private WebView printWebView;

    public WebViewPrintDocumentAdapter(Activity activity, String html, String invoice) {
        this.activity = activity;
        this.html = html;
        this.invoice = invoice;
    }

    @Override
    public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                          CancellationSignal cancellationSignal,
                          LayoutResultCallback callback, Bundle extras) {
        printWebView = new WebView(activity);
        printWebView.getSettings().setJavaScriptEnabled(false);
        printWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (cancellationSignal.isCanceled()) {
                    callback.onLayoutCancelled();
                    return;
                }
                PrintDocumentInfo info = new PrintDocumentInfo.Builder(
                        "NKSE-" + invoice + ".pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .build();
                callback.onLayoutFinished(info, true);
            }
        });
        printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    @Override
    public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                        CancellationSignal cancellationSignal, WriteResultCallback callback) {
        PrintDocumentAdapter adapter = printWebView.createPrintDocumentAdapter(invoice);
        adapter.onWrite(pages, destination, cancellationSignal, callback);
    }
}
