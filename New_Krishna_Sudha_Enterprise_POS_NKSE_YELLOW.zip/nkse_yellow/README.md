# New Krishna Sudha Enterprise - Bill/Print Fixed

This Android WebView POS project fixes:
- Bill data saving with WebView DOM storage enabled.
- Native Android PrintManager printing from the saved bill.
- Re-printing from Sales History.
- Browser fallback printing when the Android bridge is unavailable.

Build: `gradle assembleDebug` with Java 17.


## UI Theme
- Yellow/gold NKSE POS theme
- Centered `POS NKSE` header
- New Krishna Sudha Enterprise shown below the title
