# HardwareStoreLedger GitHub Actions package

IMPORTANT:
1. Upload the CONTENTS of this ZIP to the repository root, not the ZIP itself.
2. Delete/disable the old workflow that contains `Find and extract ZIP` or `settings.gradle not found`.
3. Keep:
   - HardwareStoreLedger.apk
   - .github/workflows/build.yml
4. Open GitHub -> Actions -> Package HardwareStoreLedger APK -> Run workflow.
5. After it finishes, open Artifacts -> HardwareStoreLedger-APK.

This workflow packages the existing APK. It intentionally does NOT run Gradle because this package does not contain the complete Android source project.
